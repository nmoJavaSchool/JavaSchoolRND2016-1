package ru.sbrf.course;

/**
 * Created by Student on 04.08.2016.
 */
public class DicounteRegistryImpl implements DiscountRegistry {

    public int getDiscount(Item item) {
        return 0;
    }
}
