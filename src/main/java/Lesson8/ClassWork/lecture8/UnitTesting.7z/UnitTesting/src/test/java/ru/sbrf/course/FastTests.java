package ru.sbrf.course;

public interface FastTests {
}
