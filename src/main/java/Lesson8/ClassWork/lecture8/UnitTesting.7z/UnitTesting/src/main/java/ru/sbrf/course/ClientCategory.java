package ru.sbrf.course;

public enum ClientCategory {

    BASIC, PRIVILEGED

}
